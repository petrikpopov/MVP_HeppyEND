﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MPV_END
{
    public partial class Form1 : Form, IView
    {
       
        public Form1()
        {
            InitializeComponent();
        }

        //public ListBox SearchResultsListBox { get { return SearchResultsListBox; } }
        
        public string SearchName_P 
        {
            set { textBox3.Text = value; }
            get { return textBox3.Text; } 
        }
        public string Name_P
        {
            set { textBox1.Text = value; }
            get { return textBox1.Text; }
        }
        public string Age_P
        {
            set { textBox2.Text = value; }
            get { return textBox2.Text; }
        }

        public event EventHandler<EventArgs> buut;
        public event EventHandler<EventArgs> print;
        public event EventHandler<EventArgs> search;
       
        public void ShowPersone(string SearchName_P)
        {
            
            textBox4.Text = SearchName_P;
           
        }
        public void ShowPeopleList(List<string> people)
        {
            listBox1.Items.Clear();

            foreach (string item in people) 
            {
                listBox1.Items.Add(item);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            buut?.Invoke(this, EventArgs.Empty);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            print?.Invoke(this,EventArgs.Empty);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            search?.Invoke(this, EventArgs.Empty);
        }
    }
}
