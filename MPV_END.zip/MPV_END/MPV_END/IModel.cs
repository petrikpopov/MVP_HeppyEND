﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MPV_END
{
    public interface IModel
    {
        string Name_P { set; get; }
        string Age_P { set; get; }
       
        void AddInfoFile_P();
        List<string> GetAllPeople();
        string SearchByName(string nameToSearch);
    }
}
