﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace MPV_END
{
    public class Model : IModel
    {
        public string PathFile = "Person.txt";
        public string Name_P { set; get; }
        public string Age_P { set; get; }

        public Model() { }
        public void AddInfoFile_P()
        {
            using (StreamWriter writet = new StreamWriter(PathFile, true))
            {

                writet.WriteLine($"Name:{Name_P}\tAge:{Age_P}");
                writet.Close();
                MessageBox.Show("Вы добавили пользователя!");
            }
        }
        public List<string> GetAllPeople()
        { 
            List<string> pers = new List<string>();
            using (StreamReader reader = new StreamReader(PathFile,true))
            {
                string line;
                while ((line=reader.ReadLine())!=null)
                {
                    pers.Add(line);
                }
            }
            return pers;
        }
        public string SearchByName(string nameToSearch)
        {
            using (StreamReader reader = new StreamReader(PathFile, true))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.Contains($"Name:{nameToSearch}"))
                    {

                        return line;
                    }
                }
                return "Такой персоны нет!!";
            }
        }
    }

}

