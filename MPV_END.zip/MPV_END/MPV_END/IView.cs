﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MPV_END
{
    public interface IView
    {
        string Name_P { set; get; }
        string Age_P { set; get; }
        
        event EventHandler<EventArgs> buut;
        event EventHandler<EventArgs> print;
        void ShowPeopleList(List<string> people);
        string SearchName_P { set; get; }

        event EventHandler<EventArgs> search;

        void ShowPersone(string name);// это метод используется при поиске и отображает
    }
}
